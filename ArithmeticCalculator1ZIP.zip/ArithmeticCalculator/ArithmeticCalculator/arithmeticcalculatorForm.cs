﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArithmeticCalculator
{
    public partial class arithmeticcalculatorForm : Form
    {
        public arithmeticcalculatorForm()
        {
            InitializeComponent();
        }
        float num, ans;
        int count;


        public void disable() // Create method to disable calculator
        {
            //Follow are Disable when call we disable() function

            textBox1.Enabled = false;
            button1.Show(); //It will be still Display
            button20.Hide(); //It will be Hide
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
            button17.Enabled = false;
            button18.Enabled = false;
            button19.Enabled = false;
 }
        private void enable() //create function to ON calculator
        {
            //Follow are Enabled when we call enable() function

            textBox1.Enabled = true;
            button20.Show(); //It will be still Display
            button1.Hide(); //It will be Hide
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;
            button11.Enabled = true;
            button12.Enabled = true;
            button13.Enabled = true;
            button14.Enabled = true;
            button15.Enabled = true;
            button16.Enabled = true;
            button17.Enabled = true;
            button18.Enabled = true;
            button19.Enabled = true;

        }
        
        private void button18_Click(object sender, EventArgs e)
        {
            // Displayed dot(.) in Textbox when press dot(.) button with Red color
            textBox1.Text = textBox1.Text + ".";
            textBox1.ForeColor = Color.Red;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            // Displayed 0 in Textbox when press 0 button with Red color
            textBox1.Text = textBox1.Text + 0;
            textBox1.ForeColor = Color.Red;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            // Displayed 1 in Textbox when press 1 button with Red color
            textBox1.Text = textBox1.Text + 1;
            textBox1.ForeColor = Color.Red;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // Displayed 2 in Textbox when press 2 button with Red color
            textBox1.Text = textBox1.Text + 2;
            textBox1.ForeColor = Color.Red;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            // Displayed 3 in Textbox when press 3 button with Red color
            textBox1.Text = textBox1.Text + 3;
            textBox1.ForeColor = Color.Red;

        }

        private void button12_Click(object sender, EventArgs e)
        {
            // Displayed 4 in Textbox when press 4 button with Red color
            textBox1.Text = textBox1.Text + 4;
            textBox1.ForeColor = Color.Red;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // Displayed 5 in Textbox when press 5 button with Red color
            textBox1.Text = textBox1.Text + 5;
            textBox1.ForeColor = Color.Red;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // Displayed 6 in Textbox when press 6 button with Red color
            textBox1.Text = textBox1.Text + 6;
            textBox1.ForeColor = Color.Red;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Displayed 7 in Textbox when press 7 button with Red color
            textBox1.Text = textBox1.Text + 7;
            textBox1.ForeColor = Color.Red;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Displayed 8 in Textbox when press 8 button with Red color
            textBox1.Text = textBox1.Text + 8;
            textBox1.ForeColor = Color.Red;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Displayed 9 in Textbox when press 8 button with Red color
            textBox1.Text = textBox1.Text + 9;
            textBox1.ForeColor = Color.Red;
        }

        private void button1_Click(object sender, EventArgs e) //On Button
        {
            enable(); //call Enable() function to On calculator
        }

        private void button20_Click(object sender, EventArgs e) //Off Button
        {
            disable(); //call Disable() function to Off calculator

        }

        private void button4_Click(object sender, EventArgs e) //Addition Button
        {
            num = float.Parse(textBox1.Text);
            textBox1.Clear();  //Clear the TextBox
            textBox1.Focus();  //Focus on Textbox after clearing Textbox
            count = 1;          //Count store case
            label1.Text = num.ToString() + "+"; //Display Text on label
        }

        private void button6_Click(object sender, EventArgs e) //Subtraction Button
        {
            num = float.Parse(textBox1.Text);
            textBox1.Clear();  //Clear the TextBox
            textBox1.Focus();  //Focus on Textbox after clearing Textbox
            count = 2;          //Count store case
            label1.Text = num.ToString() + "-"; //Display Text on label
        }

        private void button9_Click(object sender, EventArgs e) //Multiplication Button
        {
            num = float.Parse(textBox1.Text);
            textBox1.Clear();  //Clear the TextBox
            textBox1.Focus();  //Focus on Textbox after clearing Textbox
            count = 3;          //Count store case
            label1.Text = num.ToString() + "*"; //Display Text on label
        }

        private void button16_Click(object sender, EventArgs e) //Division Button
        {

            num = float.Parse(textBox1.Text);
            textBox1.Clear();  //Clear the TextBox
            textBox1.Focus();  //Focus on Textbox after clearing Textbox
            count = 4;          //Count store case
            label1.Text = num.ToString() + "/"; //Display Text on label
        }
            
            


        private void button19_Click(object sender, EventArgs e)
        {
            compute(); //Call compute() function to perform operations
            label1.Text = ""; //Clear the text on the label
        }

        private void button3_Click(object sender, EventArgs e)  //Clear Button
        {
            textBox1.Text = ""; //Clear the text on the textbox
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int length = textBox1.TextLength - 1;
            string text = textBox1.Text;
            textBox1.Clear();
            for (int i = 0; i < length; i++)
                textBox1.Text = textBox1.Text + text[i];
        }

        public void compute()
        {
            switch(count) //Creating switch statement
            {

                case 1:
                    ans = num + float.Parse(textBox1.Text);  //It performs Addition
                    textBox1.Text = ans.ToString();         //Converted float into string
                    break;

                case 2:
                    ans = num - float.Parse(textBox1.Text);  //It performs Subtraction
                    textBox1.Text = ans.ToString();         //Converted float into string
                    break;

                case 3:
                    ans = num * float.Parse(textBox1.Text);  //It performs Multiplication
                    textBox1.Text = ans.ToString();         //Converted float into string
                    break;

                case 4:
                    ans = num / float.Parse(textBox1.Text);  //It performs Division
                    textBox1.Text = ans.ToString();         //Converted float into string 
                    break;

                default:
                    break;

            }
        }
    }
}
